import React from 'react';

const CompContact = () => {
  return (
    <section>
      온라인문의
    </section>
  );
};

export default CompContact;
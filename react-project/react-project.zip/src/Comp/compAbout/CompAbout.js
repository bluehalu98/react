import React from 'react';

const CompAbout = () => {
  return (
    <section>
      인사말...
    </section>
  );
};

export default CompAbout;
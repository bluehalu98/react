import React from 'react';

const CompBizIntro = () => {
  return (
    <section>
      사업소개
    </section>
  );
};

export default CompBizIntro;
import React from 'react';

const CompLocation = () => {
  return (
    <section>
      오시는길...
    </section>
  );
};

export default CompLocation;
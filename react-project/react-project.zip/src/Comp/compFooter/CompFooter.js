import React from 'react';

const CompFooter = () => {
  return (
    <footer>
      <hr />
      footer...
    </footer>
  );
};

export default CompFooter;
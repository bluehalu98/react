import React from 'react';

const CompGallery = () => {
  return (
    <section>
      갤러리...
    </section>
  );
};

export default CompGallery;
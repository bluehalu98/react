import React from 'react';

const Comp404 = () => {
  return (
    <section>
      404 에러
    </section>
  );
};

export default Comp404;
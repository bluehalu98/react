import React from 'react';

const CompHome = () => {
  return (
    <>
      <section className="home-visual">
        홈비주얼...
      </section>
      <main className='home-content'>
        첫페이지...
      </main>
    </>
  );
};

export default CompHome;
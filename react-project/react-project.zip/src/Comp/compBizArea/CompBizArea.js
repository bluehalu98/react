import React from 'react';

const CompBizArea = () => {
  return (
    <section>
      사업영역
    </section>
  );
};

export default CompBizArea;